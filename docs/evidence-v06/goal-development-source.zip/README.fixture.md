# 验收说明
add返回两数之和。
python -m unittest discover -s tests
