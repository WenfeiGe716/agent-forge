---
name: v07-review-checklist-1788926654
description: 在定向需求和代码审查阶段核对接口、边界与验收证据。
---
# 协作约定

先明确用户需求。不足时request_decision。读取references/checklist.md；形成责任人明确的行动项。
